// ServerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Server.h"
#include "ServerDlg.h"
#include "afxdialogex.h"
#include "afxsock.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

	// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CServerDlg dialog



CServerDlg::CServerDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_SERVER_DIALOG, pParent)
	, Message(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CServerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_Mesg, Message);
	DDX_Control(pDX, IDC_Mesg, CMessage);
}

BEGIN_MESSAGE_MAP(CServerDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_Listen, &CServerDlg::OnBnClickedListen)
	ON_BN_CLICKED(IDC_Cancel, &CServerDlg::OnBnClickedCancel)
	ON_EN_CHANGE(IDC_Mesg, &CServerDlg::OnEnChangeMesg)
END_MESSAGE_MAP()


void CServerDlg::showMessage(string s) {
	Message += Converter::StringToChar(s);
	Message += "\r\n";
	CMessage.SetWindowTextW(Message);
}


// CServerDlg message handlers

BOOL CServerDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	if (AfxSocketInit() == FALSE) {
		showMessage("Can't connect with client");
		return false;
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CServerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CServerDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CServerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CServerDlg::send(CSocket & socket, char * ServerMsg) {
	int MsgSize;
	MsgSize = strlen(ServerMsg);
	socket.Send(&MsgSize, sizeof(MsgSize), 0);
	socket.Send(ServerMsg, MsgSize, 0);

}

char *  CServerDlg::receive(CSocket & server) {

	int MsgSize;
	char *temp;
	int status = server.Receive((char*)&MsgSize, sizeof(int), 0);
	if (status == 0 || status == SOCKET_ERROR) {
		return "";
	}	
	temp = new char[MsgSize + 1];
	server.Receive((char*)temp, MsgSize, 0);
	temp[MsgSize] = '\0';
	return temp;
}


string CServerDlg:: getexepath() {
	char NPath[MAX_PATH];
	GetCurrentDirectoryA(MAX_PATH, NPath);
	return string(NPath);
}



bool CServerDlg::logIn(User user) {
	
	ifstream input;
	input.open("ClientDatabase.txt");
	string name;
	string password;
	while (input >> name) {
		input >> password;
		if (user.name == name && user.password == password) {
			input.close();
			return 1;
		}
	}
	input.close();
	return 0;
}

bool CServerDlg::signUp(User user) {

	for (int i = 0; i < user.name.size(); i++) if (user.name[i] == '$') return 0;
	
	string name;
	string password;
	ifstream input;
	input.open("ClientDatabase.txt");
	while (input >> name) {
		input >> password;
		if (user.name == name) {
			input.close();
			return 0;
		}
	}
	input.close();


	ofstream output;
	output.open("ClientDatabase.txt", fstream::app);
	output << user.name << endl;
	output << user.password << endl;
	output.close();

	return 1;

}

vector<string> CServerDlg::ls() {
	vector<string> names;
	WIN32_FIND_DATA search_data;

	memset(&search_data, 0, sizeof(WIN32_FIND_DATA));
	
	HANDLE handle = FindFirstFile(Converter::stringToCString(getexepath())+"/*.*", &search_data);

	while (handle != INVALID_HANDLE_VALUE)
	{
		wstring ws = search_data.cFileName;
		string s(ws.begin(), ws.end());
		names.push_back(s);
		if (FindNextFile(handle, &search_data) == FALSE)
			break;
	}
	return names;
}
void CServerDlg:: put(CSocket& client, string name) {
	int t;
	client.Receive(&t, sizeof(int));
	long long int size;

	if (t == 0)
	{
		showMessage("Receive no file from client\r\n");
		return;
	}
	client.Receive(&size, sizeof(long long int));
	FILE* file;
	int count;
	char buf[BIT_PER_UNIT];
	file = fopen(name.c_str(), "wb");
	while (1) {
		count = 0;
		client.Receive(&count, sizeof(int));
		client.Receive(buf, count);
		fwrite(buf, 1, count, file);
		if (count != BIT_PER_UNIT)
			break;
	}
	long long int byte1;
	fseek(file, 0, SEEK_END);
	byte1 = ftell(file);
	fclose(file);
	if (byte1 == size)
	{
		showMessage("Receive file successfully from client\r\n");
		t = 1;
		client.Send(&t, sizeof(int));
	}
	else
	{
		showMessage("Failed to receive file from client\r\n");
		t = 0;
		client.Send(&t, sizeof(int));
		remove(name.c_str());
	}

}

void CServerDlg:: get(CSocket& client, string name) {
	FILE *fin;
	fin = fopen(name.c_str(), "rb");
	int t = 1;
	if (fin == NULL)
	{
		t = 0;
		client.Send(&t, sizeof(int));
		showMessage("Such file doesn't exist in server's folder");
		return;
	}

	client.Send(&t, sizeof(int));
	long long int size;
	fseek(fin, 0, SEEK_END);
	size = ftell(fin);
	fseek(fin, 0, SEEK_SET);
	client.Send(&size, sizeof(long long int));
	char rsp[BIT_PER_UNIT];
	while (1)
	{
		memset(rsp, 0, BIT_PER_UNIT);
		int byteRec = fread(rsp, 1, BIT_PER_UNIT, fin);
		if (byteRec == 0) {
			break;
		}
		client.Send(&byteRec, sizeof(int));
		client.Send(rsp, byteRec);
	
	}
	fclose(fin);
	client.Receive(&t, sizeof(int));
	if (t == 1)
	{
		showMessage("Send file to client succesfully");
	}
	else
		showMessage("Failed to to end file to client");
}



void CServerDlg::handleMessage(CSocket & connect, char * mess) {
	
	
	string message = Converter::CharToString(mess);
	vector<string> v = Tokenizer::Parse(message, DELIMITER);
	int option = Converter::StringToNumber(v[0]);
	switch ( option ) {
	    case(LOG_IN): {
			   showMessage("Log in");
			   if( !logIn( User( v[1] ,v[2]) ) ) send(connect,"101");
			   else send(connect, "102");
		       break;
	    }
		case(SIGN_UP):{
			showMessage("Sign up");
			if (signUp(User(v[1], v[2]))) send(connect, "103");
			else send(connect, "104");
			break;
		}
		case(LS): {
			showMessage("See all folder");
			vector <string> files = ls();
			string list = "105";
			for (int i = 0; i < files.size(); i++) {
				list += '$';
				list += files[i];
			}
			send(connect, Converter::StringToChar(list));
			break;
		}
		case(PUT_FILE): {
			showMessage("Upload file to server");
			send(connect, "106");
			put(connect, v[1]);
			break;
		}
		case(GET_FILE): {
			showMessage("Download file from server");
			send(connect, "106");
			get(connect, v[1]);
			break;
		}
		case(MKDIR): {
			showMessage("Create folder in server");
			send(connect, "106");
			mkdir(connect, v[1]);
			break;
		}
		case(RMDIR): {
			showMessage("Delete folder in server");
			send(connect, "106");
			rmdir(connect, v[1]);
			break;
		}
		case(DELETE_FILE): {
			showMessage("Delete file in server");
			send(connect, "106");
			deleteFile(connect, v[1]);
			break;
		}
		default: {
			//Message += mess;
			break;
		}
	}
}

bool CServerDlg::mkdir(CSocket & client,string name) {
	int t = PathFileExistsA(name.c_str());
	if (t)
	{
		showMessage("Folder is already existed");
		client.Send(&t, sizeof(int));
		return 0;
	}
	int check = _mkdir(name.c_str());
	if (check == 0)
	{
		showMessage("Create folder successfully");
	}
	else if (check == -1)
	       showMessage("Failed to create folder");

	client.Send(&check, sizeof(int));
	return 1;
}

bool CServerDlg::rmdir(CSocket & client, string name) {
	int t = PathFileExistsA(name.c_str());
	int z;
	int y = 1;
	if (!t)
	{
		z = 0;
		showMessage("Folder doesn't exist");
		client.Send(&z, sizeof(int));
		return 0;
	}
	t = PathIsDirectoryEmptyA(name.c_str());
	if (!t)
	{
		z = 1;
		showMessage("Can't remove folder due to some problem");
		client.Send(&z, sizeof(int));
		return 0;
	}
	int check = _rmdir(name.c_str());
	if (check == 0)
	{
		z = 2;
		showMessage("Remove folder successfully");
	}
	else if (check == -1)
	{
		z = 3;
		showMessage("Failed to remove folder");
	}
	client.Send(&z, sizeof(int));
	return 1;
}

void CServerDlg::deleteFile(CSocket & client,string name) {
	int t = 1;
	FILE* file;
	file = fopen(Converter::StringToChar(name), "r");
	if (file == NULL) {
		t = 0;
		client.Send(&t, sizeof(int));
		showMessage("Such file doesn't exist");
		//fclose(file);
		return;
	}	
	fclose(file);

	remove(name.c_str());
	client.Send(&t, sizeof(int));
	showMessage("Delete file successfully");
}


void CServerDlg:: ThreadProc(int t) {
	

	while (1)
	{
		
	    char * mess = receive(*clients[t]);
	
		if(mess=="")
		{
			showMessage("Client " + Converter::CharToString(ClientId[t]) + " is out of connection");
			
			break;
		}
		else {
			   
			Message += _T("Client ");
			Message += ClientId[t];
			Message += " ";
			handleMessage(*clients[t], mess);
		}
	}
	
}

/*

bool CServerDlg::isContinued(int t,HWND * handle) {
	CString s = (t > 0) ? _T("FOUND A NEW CLIENT,") : _T("LOSING ONE OF THE CONNECTION,");
	INT_PTR i = MessageBox(s+_T("DO YOU WANT TO CONTINUE SERVING?"), _T("CONFIRM"), MB_OKCANCEL);
	if (i == IDCANCEL) {
		listen.Close();
		m.unlock();
		return 1;
	}
	return 0;
}
*/

void CServerDlg::OnBnClickedListen()
{
	// TODO: Add your control notification handler code here
	if (listen.Create(PORT, SOCK_STREAM, _T("127.0.0.1")) == 0) {
		showMessage("Failed to init socket");
		listen.GetLastError();
		return;
	}
	else {
		if (listen.Listen(1) == FALSE) {
			showMessage("Can't listen to the port");
			listen.Close();
			return;
		}

	}
	int cnt = -1;
	CSocket* client;
	
	while (1)
	{
		client = new CSocket();
	if (listen.Accept(*client))
		{
			cnt++;
			char * id = Converter::StringToChar(Converter::NumberToString(*client));
			clients.push_back(client);
			ClientId.push_back(id);

			showMessage("Found a connection with client " + Converter::CharToString(id));

			/*
					 Thread here
			*/
			threads.push_back(thread(&CServerDlg::ThreadProc, this, cnt));
		}
		else break;
	}
	listen.Close();
      
		for (int i = 0; i < clients.size(); i++)
		{
			if (clients[i] != NULL)
			{
				clients[i]->Close();
			}
		}
		clients.clear();
	
}


void CServerDlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
}

CServerDlg:: ~CServerDlg(){
	for (auto& th : threads) if(th.joinable()) th.join();
}

void CServerDlg::OnEnChangeMesg()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}
