// InputDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Client.h"
#include "InputDlg.h"
#include "afxdialogex.h"


// InputDlg dialog

IMPLEMENT_DYNAMIC(InputDlg, CDialog)

InputDlg::InputDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_InputDlg, pParent)
{

}

InputDlg::~InputDlg()
{
}

void InputDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(InputDlg, CDialog)
END_MESSAGE_MAP()


// InputDlg message handlers
