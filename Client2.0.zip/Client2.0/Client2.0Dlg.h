
// Client2.0Dlg.h : header file
//

#pragma once
#include <afxsock.h>
#include <string>
#include <winsock2.h>
#include "Converter.h"
#include "Tokenizer.h"
#include "CInputDlg.h"
#include<conio.h>
#include<direct.h>
#define PORT 1234
#define WM_SOCKET WM_USER+2
#define MAX_LEN 200
#define BIT_PER_UNIT 2048
using namespace std;

// CClient20Dlg dialog
class CClient20Dlg : public CDialogEx
{
// Construction
public:
	CClient20Dlg(CWnd* pParent = nullptr);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CLIENT20_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
private:
	SOCKET clientSocket;
	sockaddr_in servAdd;
	void setUp();
	int serverList;
	bool member;
	string getexepath();
	vector<string> ls();
	void showMessage(string);
	void sendMsg(SOCKET, string);
    bool receiveMsg(SOCKET, string &);
	LRESULT SockMsg(WPARAM wParam, LPARAM lParam);
	void put(SOCKET, string);
	bool get(SOCKET, string);
	void deleteFile(SOCKET client, string name);
	void mkdir(SOCKET, string);
	void rmdir(SOCKET, string);
public:
	CString UserName;
	CString Password;
	afx_msg void OnBnClickedLogin();
	CString Message;
	CEdit CMessage;
	bool connected;
	void handleMessage(string);
	int barcode;
	string name;

	afx_msg void OnBnClickedlogout();
	afx_msg void OnBnClickedSignup();
	CListBox fileList;
	afx_msg void OnFileDowloadfile();
	afx_msg void OnLbnSelchangeList1();
	afx_msg void OnFileUploadfile();
	afx_msg void OnFileDeletefile();
	afx_msg void OnLbnDblclkList1();
	afx_msg void OnEditCreatefoler();
	afx_msg void OnEditDeletefolder();
	afx_msg void OnBnClickedCheck();
	CButton RButt;
};
