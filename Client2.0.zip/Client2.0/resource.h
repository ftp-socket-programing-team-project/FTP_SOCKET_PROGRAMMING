//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Client20.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CLIENT20_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDR_MENU1                       130
#define IDD_DIALOG1                     131
#define IDC_EDIT1                       1000
#define IDC_UserName                    1001
#define IDC_Password                    1002
#define IDC_Message                     1003
#define IDC_Login                       1004
#define IDC_logOut                      1005
#define IDC_SignUp                      1006
#define IDC_LIST1                       1007
#define IDC_RADIO1                      1008
#define IDC_Check                       1008
#define IDC_folderName                  1009
#define ID_FILE_DOWLOADFILE             32771
#define ID_FILE_UPLOADFILE              32772
#define ID_FILE_DELETEFILE              32773
#define ID_EDIT_CREATEFOLER             32774
#define ID_EDIT_DELETEFOLDER            32775
#define ID_HELP_HE                      32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32777
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
