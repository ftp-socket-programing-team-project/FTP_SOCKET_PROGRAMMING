// CInputDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Client2.0.h"
#include "CInputDlg.h"
#include "afxdialogex.h"


// CInputDlg dialog

IMPLEMENT_DYNAMIC(CInputDlg, CDialog)

CInputDlg::CInputDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_DIALOG1, pParent)
{

}

CInputDlg::~CInputDlg()
{
}

void CInputDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_folderName, CfolderName);
}


BEGIN_MESSAGE_MAP(CInputDlg, CDialog)
	ON_BN_CLICKED(IDOK, &CInputDlg::OnBnClickedOk)
END_MESSAGE_MAP()


// CInputDlg message handlers
CString CInputDlg::getText() {
	return folder;
	
}

void CInputDlg::OnBnClickedOk()
{
	// TODO: Add your control notification handler code here
	UpdateWindow();
	GetDlgItemText(IDC_folderName, folder);
	CDialog::OnOK();
}
