
// Client2.0Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "Client2.0.h"
#include "Client2.0Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CClient20Dlg dialog



CClient20Dlg::CClient20Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_CLIENT20_DIALOG, pParent)
	, UserName(_T(""))
	, Password(_T(""))
	, Message(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CClient20Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_UserName, UserName);
	DDX_Text(pDX, IDC_Password, Password);
	DDX_Text(pDX, IDC_Message, Message);
	DDX_Control(pDX, IDC_Message, CMessage);
	DDX_Control(pDX, IDC_LIST1, fileList);
	DDX_Control(pDX, IDC_Check, RButt);
}

BEGIN_MESSAGE_MAP(CClient20Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_MESSAGE(WM_SOCKET, SockMsg)
	ON_BN_CLICKED(IDC_Login, &CClient20Dlg::OnBnClickedLogin)
	ON_BN_CLICKED(IDC_logOut, &CClient20Dlg::OnBnClickedlogout)
	ON_BN_CLICKED(IDC_SignUp, &CClient20Dlg::OnBnClickedSignup)
	ON_COMMAND(ID_FILE_DOWLOADFILE, &CClient20Dlg::OnFileDowloadfile)
	ON_LBN_SELCHANGE(IDC_LIST1, &CClient20Dlg::OnLbnSelchangeList1)
	ON_COMMAND(ID_FILE_UPLOADFILE, &CClient20Dlg::OnFileUploadfile)
	ON_COMMAND(ID_FILE_DELETEFILE, &CClient20Dlg::OnFileDeletefile)
	ON_LBN_DBLCLK(IDC_LIST1, &CClient20Dlg::OnLbnDblclkList1)
	ON_COMMAND(ID_EDIT_CREATEFOLER, &CClient20Dlg::OnEditCreatefoler)
	ON_COMMAND(ID_EDIT_DELETEFOLDER, &CClient20Dlg::OnEditDeletefolder)
	ON_BN_CLICKED(IDC_Check, &CClient20Dlg::OnBnClickedCheck)
END_MESSAGE_MAP()


// CClient20Dlg message handlers

BOOL CClient20Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	member = false;
	RButt.SetCheck(BST_UNCHECKED);
	GetDlgItem(IDC_logOut)->EnableWindow(false);
	return TRUE;  // return TRUE  unless you set the focus to a control
}
void CClient20Dlg::setUp() {
	WSADATA wsd;
	WSAStartup(MAKEWORD(2, 2), &wsd);
	clientSocket = socket(AF_INET, SOCK_STREAM, 0);
	hostent* host = NULL;
	if (clientSocket == INVALID_SOCKET)
	{
		MessageBox(_T("Can't create socket"), _T("ERROR"), 0);
		RButt.SetCheck(BST_UNCHECKED);
		return;
	}

	servAdd.sin_family = AF_INET;
	servAdd.sin_port = htons(PORT);
	/*
	char* cIP = ConvertToChar(IP);
	*/
	char * IP = "127.0.0.1";
	servAdd.sin_addr.s_addr = inet_addr(IP);

	CStringA cpy_IP(IP);

	if (servAdd.sin_addr.s_addr == INADDR_NONE)
	{
		host = (gethostbyname(cpy_IP));
		if (host == NULL)
		{
			MessageBox(_T("Can't connect to server."), _T("ERROR"), 0);
			RButt.SetCheck(BST_UNCHECKED);
		}
		CopyMemory(&servAdd.sin_addr, host->h_addr_list[0],
			host->h_length);
		return;
	}
	int err = connect(clientSocket, (struct sockaddr*)&servAdd, sizeof(servAdd));
	if (err == SOCKET_ERROR) {
		MessageBox(_T("Failed to connect"), _T("ERROR"), 0);
		RButt.SetCheck(BST_UNCHECKED);
		return;
	}
	WSAAsyncSelect(clientSocket, m_hWnd, WM_SOCKET, FD_READ | FD_CLOSE);
}
void CClient20Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CClient20Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CClient20Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CClient20Dlg::showMessage(string s) {
	CMessage.SetWindowTextW(Converter::stringToCString(s));
}


void CClient20Dlg::sendMsg(SOCKET client, string mess) {
	char * buffer = Converter::StringToChar(mess);
	int len = mess.size() + 1;
	send(client, (char*)&len, sizeof(len), 0);
	send(client, (char*)buffer, len, 0);
	delete buffer;

}

bool CClient20Dlg::receiveMsg(SOCKET client, string & mess) {
	//showMessage(mess);
	int len;
	char * buffer;
	recv(client, (char*)&len, sizeof(int), 0);
	buffer = new char[len+1];
	recv(client, (char*)buffer, len, 0);
	buffer[len] = '\0';
	mess = Converter::CharToString(buffer);
	return mess.size() != 0;

}
string CClient20Dlg::getexepath() {
	char NPath[MAX_PATH];
	GetCurrentDirectoryA(MAX_PATH, NPath);
	return string(NPath);
}

vector<string> CClient20Dlg::ls() {
	vector<string> names;
	WIN32_FIND_DATA search_data;

	memset(&search_data, 0, sizeof(WIN32_FIND_DATA));

	HANDLE handle = FindFirstFile(Converter::stringToCString(getexepath()) + "/*.*", &search_data);

	while (handle != INVALID_HANDLE_VALUE)
	{
		wstring ws = search_data.cFileName;
		string s(ws.begin(), ws.end());
		names.push_back(s);
		if (FindNextFile(handle, &search_data) == FALSE)
			break;
	}
	return names;
}
void CClient20Dlg::put(SOCKET client, string name) {
	FILE *fin;
	fin = fopen(name.c_str(), "rb");
	int t = 1;
	if (fin == NULL)
	{
		t = 0;
		send(client, (char *)&t, sizeof(int), 0);
		showMessage("Such file doesn't exit in your folder\r\n");
		return;
	}
	send(client, (char*)&t, sizeof(int), 0);
	long long int size;
	fseek(fin, 0, SEEK_END);
	size = ftell(fin);
	fseek(fin, 0, SEEK_SET);
	send(client, (char *)&size, sizeof(long long int), 0);
	char rsp[BIT_PER_UNIT];
	while (1)
	{
		memset(rsp, 0, BIT_PER_UNIT);
		int byteRec = fread(rsp, 1, BIT_PER_UNIT, fin);

		if (byteRec == 0) {

			break;
		}
		send(client, (char *)&byteRec, sizeof(int), 0);
		send(client, rsp, byteRec, 0);
	}
	fclose(fin);
	recv(client, (char *)&t, sizeof(int), 0);
	if (t == 1)
	{
		showMessage("Upload file to server successfully");
	}
	else
		showMessage("Failed to upload file to server");
}


void CClient20Dlg::mkdir(SOCKET client, string name) {
	int check;
	recv(client,(char *)&check, sizeof(int),0);
	int t;
	recv(client, (char *)&t, sizeof(int), 0);
	showMessage(Converter::numberToString(check));
	if (check == 0)
	{
		showMessage("Create folder in server successfully");
	}
	else if (check == -1)
		showMessage("Failed to create a folder");
	else if (check == 1)
		showMessage("Folder doesn't exist");
}
void CClient20Dlg::rmdir(SOCKET client, string name)
{
	showMessage("RMDIR");
	int y;
	int z;
	recv(client,(char *)&z, sizeof(int),0);
	if (z == 0)
	{
		showMessage("Folder doesn't exist");
		return;

	}
	else if (z == 1)
	{
		showMessage("Folder contains file/files that are unable to be removed");
	}
	else if (z == 2)
	{
		showMessage("Remove folder sucessfully");
	}
	else if (z == 3)
	{
		showMessage("Failed to remove folder");
	}

}


void CClient20Dlg::get(SOCKET client, string name) {
	int t;
	recv(client,(char *)&t, sizeof(int),0);
	long long int size;

	if (t == 0)
	{
		showMessage("Such file doesn't exit in server's folder");
		return;
	}
	recv(client,(char *)&size, sizeof(long long int),0);
	FILE* file;
	int count;
	char buf[BIT_PER_UNIT];
	file = fopen(name.c_str(), "wb");
	while (1) {
		count = 0;
		recv(client,(char *)&count, sizeof(int),0);
		recv(client,buf, count,0);
		fwrite(buf, 1, count, file);
		if (count != BIT_PER_UNIT)
			break;
	}
	long long int byte1;
	fseek(file, 0, SEEK_END);
	byte1 = ftell(file);
	fclose(file);
	if (byte1 == size)
	{
		showMessage("Download file successfully");
		t = 1;
		send(client,(char *)&t, sizeof(int),0);
	}
	else
	{
		t = 0;
		send(client,(char *)&t, sizeof(int),0);
		showMessage("Failed to download file from server");
		remove(name.c_str());
	}
}

void CClient20Dlg::deleteFile(SOCKET client, string name) {
	int t;
	recv(client,(char *)&t, sizeof(int),0);
	
	if (t)
	{
		showMessage("Delete file in server successfully");
		return;
	}
	else 	showMessage("Such file doesn't exist in server");
}

void CClient20Dlg::handleMessage(string message) {
	vector<string> v = Tokenizer::Parse(message, DELIMITER);
	int option = Converter::StringToNumber(v[0]);
	switch (option) {
	case(101): {
		MessageBox(__T("PLEASE SIGN UP TO ACCESS"));
		GetDlgItem(IDC_Login)->EnableWindow(true);
		break;
	}
	case(102): {
		MessageBox(_T("LOGIN SUCCESSFULLY!!! YOU ARE CONNECTED TO SERVER"));
		GetDlgItem(IDC_logOut)->EnableWindow(true);
		GetDlgItem(IDC_SignUp)->EnableWindow(false);
		member = true;
		break;
	}
	case(103): {
		MessageBox(_T("SIGN UP SUCCESSFULLY!!! YOU ARE CONNECTED TO SERVER"));
		GetDlgItem(IDC_logOut)->EnableWindow(true);
		GetDlgItem(IDC_Login)->EnableWindow(false);
		member = true;
		break;
	}
	case(104): {
		MessageBox(__T("NAME IS INVALID OR ALREADY TAKEN.PLEASE GIVE ANORTHER TRY AND DON'T INCLUDE '$' IN YOUR NAME"));
		GetDlgItem(IDC_SignUp)->EnableWindow(true);
		GetDlgItem(IDC_Login)->EnableWindow(true);
		break;
	}
	case(105): {
		//Delete all old files
		fileList.ResetContent();
		//List of Files
		for (int i = 1; i < v.size(); i++) {
			fileList.AddString(Converter::stringToCString(v[i]));
		}
		break;
	}
	case(106): {
		showMessage("Server is working on it\r\n");
		break;
	}
/*	
	case(107): {
		break;
	}*/
	}

}

LRESULT CClient20Dlg::SockMsg(WPARAM wParam, LPARAM lParam) {
	if (WSAGETSELECTERROR(lParam))
	{
		// Display the error and close the socket
		closesocket(wParam);
	}
	switch (WSAGETSELECTEVENT(lParam))
	{
	
	case FD_READ:
	    {
		   
		   string mess;
		   if (!receiveMsg(clientSocket, mess)) return 0;
		   handleMessage(mess);
			
		   break;

	    }
	case FD_CLOSE:
	   {
		closesocket(clientSocket);
		break;
	   }

	}
	return 0;
}

void CClient20Dlg::OnBnClickedLogin()
{
	// TODO: Add your control notification handler code here
	UpdateWindow();
	GetDlgItem(IDC_Login)->EnableWindow(false);
	CString name;
	GetDlgItemText(IDC_UserName, name);
	CString pass;
	GetDlgItemText(IDC_Password, pass);

	UserName = name;
	Password = pass;
	if (UserName == "")
	{
		MessageBox(_T("Please enter user name"));
		return;
	}
	if (Password == "") {
		MessageBox(_T("Please enter your password"));
		return;
	}
	// Message here 
	string message = "1";
	message += DELIMITER + Converter::CStringToString(UserName) + DELIMITER + Converter::CStringToString(Password);

	
	sendMsg(clientSocket,message);


}


void CClient20Dlg::OnBnClickedlogout()
{
	UpdateData();
	GetDlgItem(IDC_logOut)->EnableWindow(false);
	GetDlgItem(IDC_Login)->EnableWindow(true);
	GetDlgItem(IDC_SignUp)->EnableWindow(true);

	INT_PTR i = MessageBox(__T("DO YOU WANT TO EXIT?"), _T("CONFIRM"), MB_OKCANCEL);
	if (i == IDCANCEL) {
		GetDlgItem(IDC_logOut)->EnableWindow(true);
		GetDlgItem(IDC_Login)->EnableWindow(false);
		GetDlgItem(IDC_SignUp)->EnableWindow(false);
	}
	else {
		showMessage("");
		fileList.ResetContent();
		UserName = "";
		Password = "";
		/*closesocket(clientSocket);
		ShowWindow(SW_HIDE);
		EndDialog(0);*/
	}
	UpdateData(false);

}




void CClient20Dlg::OnBnClickedSignup()
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_SignUp)->EnableWindow(false);
	GetDlgItem(IDC_Login)->EnableWindow(true);
	CString name;
	GetDlgItemText(IDC_UserName, name);
	CString pass;
	GetDlgItemText(IDC_Password, pass);

	UserName = name;
	Password = pass;
	if (UserName == "")
	{
		MessageBox(_T("Please enter user name"));
		return;
	}
	if (Password == "") {
		MessageBox(_T("Please enter your password"));
		return;
	}

	// Message here 
	string message = "2";
	message += DELIMITER + Converter::CStringToString(UserName) + DELIMITER + Converter::CStringToString(Password);

	sendMsg(clientSocket, message);

}


void CClient20Dlg::OnFileDowloadfile()
{
	// TODO: Add your command handler code here
	if (!member) {
		MessageBox(_T("YOU ARE NOT A MEMBER.PLEASE SIGN UP TO USE THIS TOOL"));
		return;
	}
	fileList.ResetContent();

	// Message here 
	string message = "3";

	sendMsg(clientSocket, message);

	serverList = 1;

}


void CClient20Dlg::OnLbnSelchangeList1()
{
	// TODO: Add your control notification handler code here	
	if (!member) {
	MessageBox(_T("YOU ARE NOT A MEMBER.PLEASE SIGN UP TO USE THIS TOOL"));
	return;
}
	int cnt = fileList.GetSelCount();

	int *lp = new int[cnt];

	int count2 = fileList.GetSelItems(cnt, lp);
	for (int i = 0; i < count2; i++)
	{
		CString str;
		fileList.GetText(lp[i], str);
		string s = Converter::CStringToString(str);
		string mess;
		switch (serverList) {
		case(1): {
			mess = "5";
			mess += DELIMITER + s;
			sendMsg(clientSocket, mess);
			get(clientSocket, s);
			break;
		}
		case(2): {
			mess = "4";
			mess += DELIMITER + s;
			sendMsg(clientSocket,mess);
			put(clientSocket, s);
			break;
		}
		case(3): {
			mess = "8";
			mess += DELIMITER + s;
			sendMsg(clientSocket, mess);
			deleteFile(clientSocket, s);
			break;
		}

		}

	}
}




void CClient20Dlg::OnFileUploadfile()
{
	// TODO: Add your command handler code here

	fileList.ResetContent();
	//List of Files
	vector<string> v = ls();
	for (int i = 1; i < v.size(); i++) {
		fileList.AddString(Converter::stringToCString(v[i]));
	}
	serverList = 2;
}


void CClient20Dlg::OnFileDeletefile()
{
	// TODO: Add your command handler code here
	if (!member) {
		MessageBox(_T("YOU ARE NOT A MEMBER.PLEASE SIGN UP TO USE THIS TOOL"));
		return;
	}
	fileList.ResetContent();

	// Message here 
	string message = "3";

	sendMsg(clientSocket, message);

	serverList = 3;
}


void CClient20Dlg::OnLbnDblclkList1()
{
	// TODO: Add your control notification handler code here
}


void CClient20Dlg::OnEditCreatefoler()
{
	// TODO: Add your command handler code here
	if (!member) {
		MessageBox(_T("YOU ARE NOT A MEMBER.PLEASE SIGN UP TO USE THIS TOOL"));
		return;
	}
	string message = "6";

	CInputDlg dialog;

	if (dialog.DoModal() == IDOK) {
		message += DELIMITER + Converter::CStringToString(dialog.getText());
		sendMsg(clientSocket, message);
		mkdir(clientSocket, Converter::CStringToString(dialog.getText()));
	}

}


void CClient20Dlg::OnEditDeletefolder()
{
	// TODO: Add your command handler code here
	if (!member) {
		MessageBox(_T("YOU ARE NOT A MEMBER.PLEASE SIGN UP TO USE THIS TOOL"));
		return;
	}
	string message = "7";

	CInputDlg dialog;

	if (dialog.DoModal() == IDOK) {
		message += DELIMITER + Converter::CStringToString(dialog.getText());
		sendMsg(clientSocket, message);
		rmdir(clientSocket, Converter::CStringToString(dialog.getText()));
	}
}




void CClient20Dlg::OnBnClickedCheck()
{
	// TODO: Add your control notification handler code here
	//setUp();
	switch (RButt.GetCheck())
	{
	case BST_UNCHECKED:
	{
		setUp();
		RButt.SetCheck(BST_CHECKED);
		
		break;
	}
	case BST_CHECKED:
	{
		RButt.SetCheck(BST_UNCHECKED);
		showMessage("");
		fileList.ResetContent();
		closesocket(clientSocket);
	
		break;
	}
	default:
	{
		RButt.SetCheck(BST_CHECKED);
		setUp();
	}
	}
}


