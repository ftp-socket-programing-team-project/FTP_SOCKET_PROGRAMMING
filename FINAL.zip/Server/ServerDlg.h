// ServerDlg.h : header file
//

#pragma once
#include <afxsock.h>
#include <vector>
#include <tchar.h> 
#include <Windows.h>
#include<thread>
#include <string>
#include <fstream>
#include<conio.h>
#include<direct.h>
#include <mutex>
#include<filesystem>
#include "Converter.h"
#include "Tokenizer.h"
#include <chrono>
#pragma warning(disable : 4996)
using namespace std;
#define MESSAGE_MAXIMUM_LEN 100
#define DELIMITER "$"
#define BIT_PER_UNIT 2048
#define OUT_OF_SERVICE "OUT_OF_SERVICE"
#define PORT 1234

// CServerDlg dialog
struct User {
	string name;
	string password;
	User() {

	}
	User(string a, string b) {
		name = a;
		password = b;
	}
};

enum MessageType {
	LOG_IN =1,
	SIGN_UP=2,
	LS =3,
	PUT_FILE=4,
	GET_FILE=5,
	MKDIR=6,
	RMDIR=7,
};



typedef struct Params Params;

class CServerDlg : public CDialogEx
{
	// Construction
public:
	CServerDlg(CWnd* pParent = nullptr);	// standard constructor
	// destruction added
	~CServerDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SERVER_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CString Message;
	afx_msg void OnBnClickedListen();
	afx_msg void OnBnClickedCancel();

private:
	vector <CSocket *> clients;
	vector <thread> threads;
	vector <char *> ClientId;
	CSocket listen;
	bool terminate;
	mutex m;

private:
	void showMessage(string);
	void send(CSocket &, char *);
	char * receive(CSocket &);
	void handleMessage(CSocket &, char *);
	bool logIn(User);
	bool signUp(User);
	bool mkdir(CSocket &, string);
	bool rmdir(CSocket &, string);
	string getexepath();
	vector<string> ls();
	void put(CSocket &, string);
	void get(CSocket &, string);
	void ThreadProc(int);
	bool isContinued(int,HWND *);
public:
	CEdit CMessage;
	afx_msg void OnEnChangeMesg();
};



