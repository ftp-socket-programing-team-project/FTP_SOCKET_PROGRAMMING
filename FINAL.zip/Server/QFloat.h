#pragma once
#include <iostream>
#include<sstream>
using namespace std;
class QFloat
{
private:
	unsigned int num[4];
private:
	void setBit(unsigned int & x, int i);       
	int getBit(unsigned int x, int i);
	string Div2(string s, int &carry);
	string IntegerToBinary(string s);
	string Multify2(string s, int &carry);
	string FractionToBinary(string s, string Integer);
	string normalize(string s, int point, int & exp);
	string findExponent(int exp);
	string find_IEE754(string s);
	QFloat Float(string s);
	int getExp(bool *);
	bool smaller(bool *, bool *,int,int,int,int);
	bool isAllZero(bool *,int ,int);
	bool isInf(QFloat );
	bool isNaN(QFloat );
	bool * round(bool *);
	string round (string );
	bool  * addTwoZeroForRounding(bool *);
public:
	void ScanQfloat(QFloat & x);
	void PrintQfloat(QFloat x);
	QFloat BinToDec(bool * bit);
	bool * DecToBin(QFloat x);
	QFloat operator + (const QFloat &);
	QFloat operator - (const QFloat &);
	QFloat operator * (const QFloat &);
	QFloat operator / (const QFloat &);
	bool operator == (const QFloat & );
public:
	QFloat();
	~QFloat();
};


