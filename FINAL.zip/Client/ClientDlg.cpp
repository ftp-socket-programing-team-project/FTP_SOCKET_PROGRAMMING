// ClientDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Client.h"
#include "ClientDlg.h"
#include "CInputDlg.h"
#include "afxdialogex.h"
#include "afxsock.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


CSocket Client;
bool serverList;

unsigned int port;

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CClientDlg dialog



CClientDlg::CClientDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_CLIENT_DIALOG, pParent)
	, UserName(_T(""))
	, Container(_T(""))
	, Password(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_User_Name, UserName);
	DDX_Text(pDX, IDC_Container, Container);
	DDX_Text(pDX, IDC_Password, Password);
	DDX_Control(pDX, IDC_fileList, fileList);
	DDX_Control(pDX, IDC_Container, CContainer);
	DDX_Control(pDX, IDC_User_Name, CUserName);
	DDX_Control(pDX, IDC_Password, CPassword);
}

BEGIN_MESSAGE_MAP(CClientDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_LogIn, &CClientDlg::OnBnClickedLogin)
	ON_BN_CLICKED(IDC_Logout, &CClientDlg::OnBnClickedLogout)
	ON_BN_CLICKED(IDC_SignUp, &CClientDlg::OnBnClickedSignup)

	ON_EN_CHANGE(IDC_Container, &CClientDlg::OnEnChangeContainer)
	ON_COMMAND(ID_FILE_OPEN, &CClientDlg::OnFileOpen)
	ON_LBN_SELCHANGE(IDC_fileList, &CClientDlg::OnLbnSelchangefilelist)
	ON_LBN_DBLCLK(IDC_fileList, &CClientDlg::OnLbnDblclkfilelist)
	ON_COMMAND(ID_HELP_HELP32774, &CClientDlg::OnHelpHelp32774)
	ON_COMMAND(ID_FILE_SEESERVERFOLDER, &CClientDlg::OnFileSeeserverfolder)
	ON_COMMAND(ID_EDIT_CREATEFOLDER, &CClientDlg::OnEditCreatefolder)
	ON_COMMAND(ID_EDIT_DELETEFOLDER, &CClientDlg::OnEditDeletefolder)
END_MESSAGE_MAP()

void CClientDlg::showMessage(string s) {
	CContainer.SetWindowTextW(Converter::stringToCString(s));
}



// CClientDlg message handlers

BOOL CClientDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	

	if (AfxSocketInit() == FALSE) {
		showMessage("Cant init socket");
		return FALSE;
	}

	Client.Create();

	member = false;
	GetDlgItem(IDC_Logout)->EnableWindow(false);

	// set list to have no item

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CClientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CClientDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CClientDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}
bool CClientDlg::send(CSocket & socket, char * ServerMsg) {
	int MsgSize;
	MsgSize = strlen(ServerMsg);

	if( socket.Send(&MsgSize, sizeof(MsgSize), 0) == SOCKET_ERROR) return 0;
	socket.Send(ServerMsg, MsgSize, 0);
	return 1;

}
char * CClientDlg::receive(CSocket & client) {
	int MsgSize;
	char *temp; 
	if (client.Receive((char*)&MsgSize, sizeof(int), 0) == 0) {
		return "";
	}// Neu nhan loi thi tra ve la SOCKET_ERROR.	
	temp = new char[MsgSize + 1];
	client.Receive((char*)temp, MsgSize, 0);
	temp[MsgSize] = '\0';
	return temp;
	delete temp;
}

void CClientDlg::handleMessage(char * mess) {
	string message = Converter::CharToString(mess);
	vector<string> v = Tokenizer::Parse(message, DELIMITER);
	int option = Converter::StringToNumber(v[0]);
	switch (option) {
	      case(101): {
			  MessageBox(__T("PLEASE SIGN UP TO ACCESS"));
			  GetDlgItem(IDC_LogIn)->EnableWindow(true);
			//  Client.Close();
		      break;
	      }
		  case(102): {
			  MessageBox(_T("LOGIN SUCCESSFULLY!!! YOU ARE CONNECTED TO SERVER"));
			  GetDlgItem(IDC_Logout)->EnableWindow(true);
			  GetDlgItem(IDC_SignUp)->EnableWindow(false);
			  member = true;
			  break;
		  }
		  case(103): {
			  MessageBox(_T("SIGN UP SUCCESSFULLY!!! YOU ARE CONNECTED TO SERVER"));
			  GetDlgItem(IDC_Logout)->EnableWindow(true);
			  GetDlgItem(IDC_LogIn)->EnableWindow(false);
			  member = true;
		//	  Client.Close();
			  break;
		  }
		  case(104): {
			  MessageBox(__T("NAME IS INVALID OR ALREADY TAKEN.PLEASE GIVE ANORTHER TRY AND DON'T INCLUDE '$' IN YOUR NAME"));
			  GetDlgItem(IDC_SignUp)->EnableWindow(true);
			  GetDlgItem(IDC_LogIn)->EnableWindow(true);
		  }
		  case(105): {
			  //Delete all old files
			  fileList.ResetContent();
			  //List of Files
			      for (int i = 1; i < v.size(); i++) {
				      fileList.AddString(Converter::stringToCString(v[i]));
			      }
				  break;
		  }
		  case(106): {
			  showMessage("Server is working on it\r\n");
			  break;
		  }
		  case(107): {
			  break;
		  }
	}	

}
string CClientDlg::getexepath() {
	char NPath[MAX_PATH];
	GetCurrentDirectoryA(MAX_PATH, NPath);
	return string(NPath);
}

vector<string> CClientDlg::ls() {
	vector<string> names;
	WIN32_FIND_DATA search_data;

	memset(&search_data, 0, sizeof(WIN32_FIND_DATA));

	HANDLE handle = FindFirstFile(Converter::stringToCString(getexepath()) + "/*.*", &search_data);

	while (handle != INVALID_HANDLE_VALUE)
	{
		wstring ws = search_data.cFileName;
		string s(ws.begin(), ws.end());
		names.push_back(s);
		if (FindNextFile(handle, &search_data) == FALSE)
			break;
	}
	return names;
}


void CClientDlg::put(CSocket & client,string name) {
	FILE *fin;
	fin = fopen(name.c_str(), "rb");
	int t = 1;
	if (fin == NULL)
	{
		t = 0;
		client.Send(&t, sizeof(int));
		showMessage("Such file doesn't exit in your folder\r\n");
		return;
	}
	client.Send(&t, sizeof(int));

	long long int size;
	fseek(fin, 0, SEEK_END);
	size = ftell(fin);
	fseek(fin, 0, SEEK_SET);
	client.Send(&size, sizeof(long long int));
	char rsp[BIT_PER_UNIT];
	while (1)
	{
		memset(rsp, 0, BIT_PER_UNIT);
		int byteRec = fread(rsp, 1, BIT_PER_UNIT, fin);

		if (byteRec == 0) {

			break;
		}
		client.Send(&byteRec, sizeof(int));
		client.Send(rsp, byteRec);
	}
	fclose(fin);
	client.Receive(&t, sizeof(int));
	if (t == 1)
	{
		showMessage("Upload file to server successfully");
	}
	else
		showMessage("Failed to upload file to server");
}

void CClientDlg::get(CSocket& client, string name) {
	int t;
	client.Receive(&t, sizeof(int));
	long long int size;

	if (t == 0)
	{
		showMessage("Such file doesn't exit in server's folder");
		return;
	}
	client.Receive(&size, sizeof(long long int));
	FILE* file;
	int count;
	char buf[BIT_PER_UNIT];
	file = fopen(name.c_str(), "wb");
	while (1) {
		count = 0;
		client.Receive(&count, sizeof(int));
		client.Receive(buf, count);
		fwrite(buf, 1, count, file);
		if (count != BIT_PER_UNIT)
			break;
	}
	long long int byte1;
	fseek(file, 0, SEEK_END);
	byte1 = ftell(file);
	fclose(file);
	if(byte1 == size)
	{
		showMessage("Download file successfully");
		t = 1;
		client.Send(&t, sizeof(int));
	}
	else
	{
		t = 0;
		client.Send(&t, sizeof(int));
		showMessage("Failed to download file from server");
		remove(name.c_str());
	}
}


void CClientDlg::mkdir(CSocket & client,string name) {
	int check;
	client.Receive(&check, sizeof(int));
	if (check == 0)
	{

		showMessage("Create folder in server successfully");
	}
	else if (check == -1)
		showMessage("Failed to create a folder");
	else if (check == 1)
		showMessage("Folder doesn't exist");
}
void CClientDlg::rmdir(CSocket& client, string name)
{
	int y;
	int z;
	client.Receive(&z, sizeof(int));
	if (z == 0)
	{
		showMessage("Folder doesn't exist");
		return;
	}
	else if (z == 1)
	{
		showMessage("Folder contains file/files that are unable to be removed");
	}
	else if (z == 2)
	{
		showMessage("Remove folder sucessfully");
	}
	else if (z == 3)
	{
		showMessage("Failed to remove folder");
	}

}


bool CClientDlg::connect(char * mess) {
	if ( !send(Client, mess) ) {
		if (Client.Connect(_T("127.0.0.1"), PORT)) {

		//	Container += _T("Connected successfully\r\n");
			send(Client, mess);
			handleMessage(receive(Client));
			return 1;

		}
		else {
			showMessage("Cant connect to server");
			return 0;
		}
	}
	else { 
		handleMessage(receive(Client));
		return 1;
	}
		
}

void CClientDlg::OnBnClickedLogin()
{
	GetDlgItem(IDC_LogIn)->EnableWindow(false);
	UpdateWindow();
	CString name;
	GetDlgItemText(IDC_User_Name, name);
	CString pass;
	GetDlgItemText(IDC_Password, pass);
	
	UserName = name;
	Password=pass;
	// Message here 
	string message = "1";
	message+= DELIMITER + Converter:: CStringToString(UserName) + DELIMITER + Converter:: CStringToString(Password);
	
	char * mess = Converter:: StringToChar(message);
	Container += mess;

	connect(mess);


}


void CClientDlg::OnBnClickedLogout()
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_Logout)->EnableWindow(false);
	GetDlgItem(IDC_LogIn)->EnableWindow(true);
	GetDlgItem(IDC_SignUp)->EnableWindow(true);

	INT_PTR i = MessageBox(__T("DO YOU WANT TO EXIT?"), _T("CONFIRM"),MB_OKCANCEL);
	if (i == IDCANCEL) {
		GetDlgItem(IDC_Logout)->EnableWindow(true);
		GetDlgItem(IDC_LogIn)->EnableWindow(false);
		GetDlgItem(IDC_SignUp)->EnableWindow(false);
	}
	else {
		showMessage("");
		fileList.ResetContent();
		Client.Close();
		ShowWindow(SW_HIDE);
		EndDialog(0);
	}

}




void CClientDlg::OnBnClickedSignup()
{
	// TODO: Add your control notification handler code here
	UpdateData(true);
	GetDlgItem(IDC_SignUp)->EnableWindow(false);
	GetDlgItem(IDC_LogIn)->EnableWindow(true);

	// Message here 
	string message = "2";
	message += DELIMITER + Converter::CStringToString(UserName)+ DELIMITER + Converter:: CStringToString(Password);

	char * mess = Converter:: StringToChar(message);
	

	connect(mess);

}


void CClientDlg::OnEnChangeContainer()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}


void CClientDlg::OnFileOpen()
{
	// TODO: Add your command handler code here
	if (!member) {
		MessageBox(_T("YOU ARE NOT A MEMBER.PLEASE SIGN UP TO USE THIS TOOL"));
		return;
	}
	fileList.ResetContent();

	// Message here 
	string message = "3";

	char * mess = Converter::StringToChar(message);
	Container += mess;

	connect(mess);

	serverList = true;


}






void CClientDlg::OnLbnSelchangefilelist()
{
	if (!member) {
		MessageBox(_T("YOU ARE NOT A MEMBER.PLEASE SIGN UP TO USE THIS TOOL"));
		return;
	}
	// TODO: Add your control notification handler code here
	int cnt = fileList.GetSelCount();

	int *lp = new int[cnt];
	int count2 = fileList.GetSelItems(cnt, lp);
	for (int i = 0; i < count2; i++)
	{
		CString str;
		fileList.GetText(lp[i], str);
		string s = Converter::CStringToString(str);
		string mess;
		if (serverList) mess = "5";
		else mess = "4";
		mess+=DELIMITER + s;
		if (serverList) {
			connect(Converter::StringToChar(mess));
			get(Client, s);
		}
		else {
			connect(Converter::StringToChar(mess));
			put(Client, s);
		}
		
	}
}


void CClientDlg::OnLbnDblclkfilelist()
{
	/*
	// TODO: Add your control notification handler code here
	int row = fileList.GetCurSel();
	if (row < 0)
		return;
	CString s;
	fileList.GetText(row, s);

	//MessageBox(s);*/
}


void CClientDlg::OnHelpHelp32774()
{
	// TODO: Add your command handler code here
	MessageBox(_T("1. To put a file , choose 'Local Folder' in File and click on the file you want to put\r\n2. To get a file , choose 'Server Folder' in File and click on the file you want to get\r\n"));
}


void CClientDlg::OnFileSeeserverfolder()
{
	// TODO: Add your command handler code here
	fileList.ResetContent();
	//List of Files
	vector<string> v = ls();
	for (int i = 1; i < v.size(); i++) {
		fileList.AddString(Converter::stringToCString(v[i]));
	}
}




void CClientDlg::OnEditCreatefolder()
{
	if (!member) {
		MessageBox(_T("YOU ARE NOT A MEMBER.PLEASE SIGN UP TO USE THIS TOOL"));
		return;
	}
	// TODO: Add your command handler code here
	string message = "6";
	
	CInputDlg dialog;

	if (dialog.DoModal() == IDOK) {
		message += DELIMITER + Converter::CStringToString(dialog.getText());
		char * mess = Converter::StringToChar(message);
		Container += mess;
		connect(mess);
		mkdir(Client, Converter::CStringToString(dialog.getText()));
	}


}


void CClientDlg::OnEditDeletefolder()
{
	// TODO: Add your command handler code here
	if (!member) {
		MessageBox(_T("YOU ARE NOT A MEMBER.PLEASE SIGN UP TO USE THIS TOOL"));
		return;
	}
	string message = "7";

	CInputDlg dialog;

	if (dialog.DoModal() == IDOK) {
		message += DELIMITER + Converter::CStringToString(dialog.getText());
		char * mess = Converter::StringToChar(message);
		Container += mess;
		connect(mess);
		rmdir(Client, Converter::CStringToString(dialog.getText()));
	}

}
