
// ClientDlg.h : header file
//

#pragma once
#include <afxsock.h>
#include <vector>
#include <string>
#include <tchar.h> 
#include "Converter.h"
#include "Tokenizer.h"
#include<conio.h>
#include<io.h>
using namespace std;

#define MESSAGE_MAXIMUM_LEN 100
#define DELIMITER "$"
#define PORT 1234
#define BIT_PER_UNIT 2048
#define PATH L"D:\\MMT\\Client\\x64\\Release/*.*"
#pragma warning(disable : 4996)

// CClientDlg dialog
class CClientDlg : public CDialogEx
{
// Construction
public:
	CClientDlg(CWnd* pParent = nullptr);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_CLIENT_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CString IP;
	CString UserName;
	afx_msg void OnBnClickedLogin();
	afx_msg void OnBnClickedLogout();
	CString Container;
private:
	void showMessage(string);
	char *receive(CSocket & );
	bool send(CSocket &, char *);
	bool connect(char *);
	void handleMessage(char *);
	string getexepath();
	vector<string> CClientDlg::ls();
	void mkdir(CSocket &, string);
	void rmdir(CSocket &, string);
	void put(CSocket &,string);
	void get(CSocket &,string);
	void deleteFile(CSocket &, string);
	public:
	CString Password;
	bool member;
	afx_msg void OnBnClickedSignup();
	afx_msg void OnEnChangeContainer();
	afx_msg void OnFileOpen();
	CListBox fileList;
	afx_msg void OnLbnSelchangefilelist();
	afx_msg void OnLbnDblclkfilelist();
	afx_msg void OnHelpHelp32774();
	afx_msg void OnFileSeeserverfolder();
	CEdit CContainer;
	CEdit CUserName;
	CEdit CPassword;
	afx_msg void OnEditCreatefolder();
	afx_msg void OnEditDeletefolder();
	CEdit Folder;
	afx_msg void OnFileDeletefile();
};
