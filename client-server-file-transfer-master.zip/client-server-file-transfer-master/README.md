# client-server-file-transfer
This is a C++ implementation of client server file transfer program in which the server sends a file to the client.
