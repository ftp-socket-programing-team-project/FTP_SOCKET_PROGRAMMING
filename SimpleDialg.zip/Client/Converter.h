#pragma once
#include <iostream>
#include <string.h>
#include <afxsock.h>
#include <sstream> 
#pragma warning(disable : 4996)
#define DELIMITER "$"
using namespace std;
class Converter
{
public: 
	static string CharToString(char * cstr) {
		string str = string(cstr);
		return str;
	}
	static char * StringToChar(string str) {
		char *cstr = new char[str.length() + 1];
		strcpy(cstr, str.c_str());
		return cstr;
	}
	static string CStringToString(CString s) {
		// Convert a TCHAR string to a LPCSTR
		CT2CA pszConvertedAnsiString(s);
		// construct a std::string using the LPCSTR input
		string strStd(pszConvertedAnsiString);
		return strStd;

	}
	static char * CStringToChar(CString s) {
		return   StringToChar(CStringToChar(s));
	}
	static CString stringToCString(string str) {
		CString ss(str.c_str());
		return ss;
	}
	static int StringToNumber(string s) {
		stringstream ss(s);
		int x = 0;
		ss >> x;
		return x;
	}
public:
	Converter();
	~Converter();
};

