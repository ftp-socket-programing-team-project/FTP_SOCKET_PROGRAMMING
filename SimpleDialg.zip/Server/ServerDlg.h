// ServerDlg.h : header file
//

#pragma once
#include <afxsock.h>
#include <vector>
#include <tchar.h> 
#include <Windows.h>
#include <string>
#include "Converter.h"
#include "Tokenizer.h"
#pragma warning(disable : 4996)
using namespace std;
#define MESSAGE_MAXIMUM_LEN 100
#define DELIMITER "$"
#define PATH "D:\\MMT\\SimpleDialg\\Client"
#define BIT_PER_UNIT 2048

// CServerDlg dialog
struct User {
	string name;
	string password;
	User() {

	}
	User(string a, string b) {
		name = a;
		password = b;
	}
};

enum MessageType {
	LOG_IN =1,
	SIGN_UP=2,
	LS =3,
	PUT_FILE=4,
	GET_FILE=5
};

class CServerDlg : public CDialogEx
{
	// Construction
public:
	CServerDlg(CWnd* pParent = nullptr);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SERVER_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CString Message;
	afx_msg void OnBnClickedListen();
	afx_msg void OnBnClickedCancel();
private:
	vector <User> Users;
private:
	void send(CSocket &, char *);
	char * receive(CSocket &);
	void handleMessage(CSocket &, char *);
	bool logIn(User);
	bool signUp(User);
	vector<string> ls();
	void put(CSocket &, string);
	void get(CSocket &, string);
		
};

