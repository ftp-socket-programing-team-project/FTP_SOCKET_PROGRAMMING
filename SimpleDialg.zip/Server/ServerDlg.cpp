// ServerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Server.h"
#include "ServerDlg.h"
#include "afxdialogex.h"
#include "afxsock.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CSocket server;
bool stop = 0;

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

	// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CServerDlg dialog



CServerDlg::CServerDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_SERVER_DIALOG, pParent)
	, Message(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CServerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_Mesg, Message);
}

BEGIN_MESSAGE_MAP(CServerDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_Listen, &CServerDlg::OnBnClickedListen)
	ON_BN_CLICKED(IDC_Cancel, &CServerDlg::OnBnClickedCancel)
END_MESSAGE_MAP()



// CServerDlg message handlers

BOOL CServerDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	if (AfxSocketInit() == FALSE) {
		Message += _T("Can't connect with client");
		return false;
	}



	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CServerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CServerDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CServerDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CServerDlg::send(CSocket & socket, char * ServerMsg) {
	int MsgSize;
	MsgSize = strlen(ServerMsg);
	socket.Send(&MsgSize, sizeof(MsgSize), 0);
	socket.Send(ServerMsg, MsgSize, 0);

}

char *  CServerDlg::receive(CSocket & server) {

	int MsgSize;
	char *temp;
	stop = 0;
	if (server.Receive((char*)&MsgSize, sizeof(int), 0) == 0) {
		stop = 1;
		return "";
	}	
	temp = new char[MsgSize + 1];
	server.Receive((char*)temp, MsgSize, 0);
	temp[MsgSize] = '\0';
	return temp;
}


bool CServerDlg::logIn(User user) {
	for (int i = 0; i < Users.size(); i++) {

		if (user.name == Users[i].name && user.password == Users[i].password) return 1;
	}
	return 0;
}

bool CServerDlg::signUp(User user) {
	Users.push_back(user);
	return 1;
}

vector<string> CServerDlg::ls() {
	vector<string> names;
	WIN32_FIND_DATA search_data;

	memset(&search_data, 0, sizeof(WIN32_FIND_DATA));
	
	HANDLE handle = FindFirstFile(L"D:\\MMT\\SimpleDialg\\x64\\Release/*.*", &search_data);

	while (handle != INVALID_HANDLE_VALUE)
	{
		wstring ws = search_data.cFileName;
		string s(ws.begin(), ws.end());
		names.push_back(s);
		if (FindNextFile(handle, &search_data) == FALSE)
			break;
	}
	return names;
}
void CServerDlg:: put(CSocket& client, string name) {
	int t;
	client.Receive(&t, sizeof(int));
	long long int size;

	if (t == 0)
	{
		Message += _T("Receive no file from client\r\n");
		return;
	}
	client.Receive(&size, sizeof(long long int));
	FILE* file;
	int count;
	char buf[BIT_PER_UNIT];
	file = fopen(name.c_str(), "wb");
	while (1) {
		count = 0;
		client.Receive(&count, sizeof(int));
		client.Receive(buf, count);
		fwrite(buf, 1, count, file);
		if (count != BIT_PER_UNIT)
			break;
	}
	long long int byte1;
	fseek(file, 0, SEEK_END);
	byte1 = ftell(file);
	fclose(file);
	if (byte1 == size)
	{
		Message += _T("Receive file successfully from client\r\n");
		t = 1;
		client.Send(&t, sizeof(int));
	}
	else
	{
		Message += _T("Failed to receive file from client\r\n");
		t = 0;
		client.Send(&t, sizeof(int));
		remove(name.c_str());
	}

}

void CServerDlg:: get(CSocket& client, string name) {
	
	FILE *fin;
	fin = fopen(name.c_str(), "rb");
	int t = 1;
	if (fin == NULL)
	{
		t = 0;
		client.Send(&t, sizeof(int));
	//	cout << "khong ton tai file " << name << endl;
		//fclose(fin);
		Message += _T("khong ton tai file ");
		return;
	}

	client.Send(&t, sizeof(int));
	long long int size;
	fseek(fin, 0, SEEK_END);
	size = ftell(fin);
	fseek(fin, 0, SEEK_SET);
	client.Send(&size, sizeof(long long int));
	char rsp[BIT_PER_UNIT];
	while (1)
	{
		memset(rsp, 0, BIT_PER_UNIT);
		int byteRec = fread(rsp, 1, BIT_PER_UNIT, fin);

		if (byteRec == 0) {

			break;
		}
		client.Send(&byteRec, sizeof(int));
		client.Send(rsp, byteRec);
	}
	//delete rsp;
	fclose(fin);
	client.Receive(&t, sizeof(int));
	if (t == 1)
	{
		Message += _T("succesfully ");
	}   
	else Message += _T("unsuccesfully ");
}



void CServerDlg::handleMessage(CSocket & connect, char * mess) {
	
	
	UpdateData(true);
	string message = Converter::CharToString(mess);
	vector<string> v = Tokenizer::Parse(message, DELIMITER);
	int option = Converter::StringToNumber(v[0]);
	switch ( option ) {
	    case(LOG_IN): {
			   if( !logIn( User( v[1] ,v[2]) ) ) send(connect,"101");
			   else send(connect, "102");
		       break;
	    }
		case(SIGN_UP):{
			if (signUp(User(v[1], v[2]))) send(connect, "103");
			break;
		}
		case(LS): {
			vector <string> files = ls();
			string list = "104";
			for (int i = 0; i < files.size(); i++) {
				list += '$';
				list += files[i];
			}
			send(connect, Converter::StringToChar(list));
			break;
		}
		case(PUT_FILE): {
			break;
		}
		case(GET_FILE): {
			get(connect, v[1]);
		//	send(connect, "3");
			break;
		}
		default: {
		//	Message += mess;
		}
	}
	UpdateData(false);
}



int PORT = 1234;

void CServerDlg::OnBnClickedListen()
{
	UpdateData(true);
	// TODO: Add your control notification handler code here
	CSocket listen;
	if (listen.Create(PORT, SOCK_STREAM, _T("127.0.0.1")) == 0) {
		Message += _T("Failed to init socket");
		listen.GetLastError();
		return;
	}
	else {
		if (listen.Listen(1) == FALSE) {
			Message += _T("\nCan't listen to the port");
			listen.Close();
			return;
		}
	}
	CSocket connect;
	if (listen.Accept(connect)) {
		//send(connect, "HELLO FROM SERVER");
		stop = 0;
		while (!stop) {
		     handleMessage( connect,receive(connect) );
		}
	}
	connect.Close();
	listen.Close();
	UpdateData(false);
}


void CServerDlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
}
