#pragma once
#include <vector>
#include <string>
using namespace std;

class Tokenizer
{
public:
	Tokenizer() {}
	~Tokenizer() {}
public:
	static vector<string> Parse(string line, string sepector) {
		vector<string> tokens;

		int startPos = 0;
		size_t foundPos = line.find(sepector, startPos);

		while (foundPos != string::npos) {
			int count = foundPos - startPos;
			string token = line.substr(startPos, count);
			tokens.push_back(token);

			// Update
			startPos = foundPos + sepector.length();
			foundPos = line.find(sepector, startPos);

		}

		// Remain 
		int count = line.length() - startPos;
		string token = line.substr(startPos, count);
		tokens.push_back(token);

		return tokens;
	}
};
