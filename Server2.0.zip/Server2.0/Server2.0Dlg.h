
// Server2.0Dlg.h : header file
//

#pragma once

#include <afxsock.h>
#include "afxwin.h"
#include <string>
#include <vector>
#include <windows.h>
#include <winsock2.h>
#include <fstream>
#include<conio.h>
#include<direct.h>
#include "Converter.h"
#include "Tokenizer.h"
#define PORT 1234
#define WM_SOCKET WM_USER+1
#define MAX_LEN 200
#define BIT_PER_UNIT 2048
#define index first
#define id second

using namespace std;

struct Client{
	SOCKET clientSocket;
	string ID;
	Client(SOCKET a, string b) {
		clientSocket = a;
		ID = b;
	}
};
struct User {
	string name;
	string password;
	User() {

	}
	User(string a, string b) {
		name = a;
		password = b;
	}
};

// define <int,string>
typedef pair <int, string> ii;

enum MessageType {
	LOG_IN = 1,
	SIGN_UP = 2,
	LS = 3,
	PUT_FILE = 4,
	GET_FILE = 5,
	MKDIR = 6,
	RMDIR = 7,
	DELETE_FILE = 8
};



// CServer20Dlg dialog
class CServer20Dlg : public CDialogEx
{
// Construction
public:
	CServer20Dlg(CWnd* pParent = nullptr);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_SERVER20_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	

private:
    // id number
	int idNumber;
	// socket to listen
	SOCKET sockServer;
	// address class
	struct sockaddr_in serverAdd;
	// vector of clients
	vector <Client> clients;
	// send message 
	void sendMsg(SOCKET,string);
	// receive message
	bool receiveMsg(SOCKET, string &);
	// Handle connection with client
	 LRESULT SockMsg(WPARAM wParam, LPARAM lParam);
	// Handle mess 
	void handleMsg(SOCKET,string);
	// Return the right socket 
	ii getClientId(SOCKET);
	// show message
	void showMessage(string,bool b = 0);
	// get exe path
	string getexepath();
	// ls()
	vector<string> ls();
	// login
	bool logIn(User);
	// Sign up
	bool signUp(User);
	// put file
	void put(SOCKET, string);
	// get file
	void get(SOCKET, string);
	//delete file
	void deleteFile(SOCKET, string);
	//create folder
	bool mkdir(SOCKET, string);
	//delete folder
	bool rmdir(SOCKET, string);
private:
	void Listen();
public:
	afx_msg void OnEnChangeMessage();
	CString Message;
	afx_msg void OnBnClickedListen();
	afx_msg void OnBnClickedCancel();
	CEdit CMessage;
};
