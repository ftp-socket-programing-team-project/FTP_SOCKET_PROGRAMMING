
// Server2.0Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "Server2.0.h"
#include "Server2.0Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CServer20Dlg dialog



CServer20Dlg::CServer20Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_SERVER20_DIALOG, pParent)
	, Message(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CServer20Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_Message, Message);
	DDX_Control(pDX, IDC_Message, CMessage);
}

BEGIN_MESSAGE_MAP(CServer20Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_MESSAGE(WM_SOCKET, SockMsg)
	ON_EN_CHANGE(IDC_Message, &CServer20Dlg::OnEnChangeMessage)
	ON_BN_CLICKED(IDC_Listen, &CServer20Dlg::OnBnClickedListen)
	ON_BN_CLICKED(IDC_Cancel, &CServer20Dlg::OnBnClickedCancel)
END_MESSAGE_MAP()


// CServer20Dlg message handlers

BOOL CServer20Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	idNumber = 100;
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CServer20Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CServer20Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CServer20Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CServer20Dlg::Listen() {
	WSADATA wsd;
	WSAStartup(MAKEWORD(2, 2), &wsd);
	sockServer = socket(AF_INET, SOCK_STREAM, 0);
	serverAdd.sin_family = AF_INET;
	serverAdd.sin_port = htons(PORT);
	serverAdd.sin_addr.s_addr = htonl(INADDR_ANY);
	bind(sockServer, (SOCKADDR*)&serverAdd, sizeof(serverAdd));
	listen(sockServer, 5);
	int err = WSAAsyncSelect(sockServer, m_hWnd, WM_SOCKET, FD_READ | FD_ACCEPT | FD_CLOSE);
	if (err)
		MessageBox(_T("Cant call WSAAsyncSelect"));
	else showMessage("Server is opened service now.",1);

}

void CServer20Dlg::showMessage(string s,bool flag) {

	Message += Converter::StringToChar(s);
	if(flag) Message += "\r\n";
	else Message += " ";
	CMessage.SetWindowTextW(Message);
}


void CServer20Dlg::sendMsg(SOCKET client, string mess) {
	char * buffer = Converter::StringToChar(mess);
	int len = mess.size() + 1;
	send(client, (char*)&len, sizeof(len), 0);
	send(client, (char*)buffer, len, 0);
	delete buffer;

}

bool CServer20Dlg::receiveMsg(SOCKET client, string & mess) {
	int len;
	char * buffer;
	recv(client, (char*)&len, sizeof(int), 0);
	buffer = new char[len+1];
	recv(client, (char*)buffer, len, 0);
	buffer[len] = '\0';
	mess = Converter::CharToString(buffer);
	return (mess.size() != 0);

}
ii  CServer20Dlg::getClientId(SOCKET socket) {

	for (int i = 0; i < clients.size(); i++)
		if (clients[i].clientSocket == socket) return  make_pair(i, clients[i].ID);
	return make_pair(-1,"");
	   
}
bool CServer20Dlg::logIn(User user) {

	ifstream input;
	input.open("ClientDatabase.txt");
	string name;
	string password;
	while (input >> name) {
		input >> password;
		if (user.name == name && user.password == password) {
			input.close();
			return 1;
		}
	}
	input.close();
	return 0;
}
bool CServer20Dlg::signUp(User user) {

	for (int i = 0; i < user.name.size(); i++) if (user.name[i] == '$') return 0;
	
	string name;
	string password;
	ifstream input;

	input.open("ClientDatabase.txt");
	while (input >> name) {
		input >> password;
		if (user.name == name) {
			input.close();
			return 0;
		}
	}
	input.close();


	ofstream output;
	output.open("ClientDatabase.txt", fstream::app);
	output << user.name << endl;
	output << user.password << endl;
	output.close();

	return 1;

}
string CServer20Dlg::getexepath() {
	char NPath[MAX_PATH];
	GetCurrentDirectoryA(MAX_PATH, NPath);
	return string(NPath);
}

vector<string> CServer20Dlg::ls() {
	vector<string> names;
	WIN32_FIND_DATA search_data;

	memset(&search_data, 0, sizeof(WIN32_FIND_DATA));

	HANDLE handle = FindFirstFile(Converter::stringToCString(getexepath()) + "/*.*", &search_data);

	while (handle != INVALID_HANDLE_VALUE)
	{
		wstring ws = search_data.cFileName;
		string s(ws.begin(), ws.end());
		names.push_back(s);
		if (FindNextFile(handle, &search_data) == FALSE)
			break;
	}
	return names;
}

void CServer20Dlg::put(SOCKET client, string name) {
	int t;
	recv(client,(char*)&t, sizeof(int),0);
	long long int size;

	if (t == 0)
	{
		showMessage("Receive no file from client\r\n");
		return;
	}
	recv(client,(char *)&size, sizeof(long long int),0);
	FILE* file;
	int count;
	char buf[BIT_PER_UNIT];
	file = fopen(name.c_str(), "wb");
	while (1) {
		count = 0;

	    recv(client,(char *)&count, sizeof(int),0);
		recv(client,buf, count,0);
		fwrite(buf, 1, count, file);
		if (count != BIT_PER_UNIT)
			break;
	} 
	long long int byte1;
	fseek(file, 0, SEEK_END);
	byte1 = ftell(file);
	fclose(file);
	if (byte1 == size)
	{
		showMessage("Receive file successfully from client\r\n");
		t = 1;
		send(client,(char *)&t, sizeof(int),0);
	}
	else
	{
		showMessage("Failed to receive file from client\r\n");
		t = 0;
		send(client,(char *)&t, sizeof(int),0);
		remove(name.c_str());
	}

}
void CServer20Dlg::get(SOCKET client, string name) {
	FILE *fin;
	fin = fopen(name.c_str(), "rb");
	int t = 1;
	if (fin == NULL)
	{
		t = 0;
	    send(client,(char *)&t, sizeof(int),0);
		showMessage("Such file doesn't exist in server's folder",1);
		return;
	}

	send(client,(char *)&t, sizeof(int),0);
	long long int size;
	fseek(fin, 0, SEEK_END);
	size = ftell(fin);
	fseek(fin, 0, SEEK_SET);
	send(client,(char *)&size, sizeof(long long int),0);
	char rsp[BIT_PER_UNIT];
	while (1)
	{
		memset(rsp, 0, BIT_PER_UNIT);
		int byteRec = fread(rsp, 1, BIT_PER_UNIT, fin);
		if (byteRec == 0) {
			break;
		}
	    send(client,(char*)&byteRec, sizeof(int),0);
		send(client,rsp, byteRec,0);

	}
	fclose(fin);
    recv(client,(char *)&t, sizeof(int),0);
	if (t == 1)
	{
		showMessage("Send file to client succesfully",1);
	}
	else
		showMessage("Failed to send file to client",1);
}

void CServer20Dlg::deleteFile(SOCKET client, string name) {
	int t = 1;
	FILE* file;
	file = fopen(Converter::StringToChar(name), "r");
	if (file == NULL) {
		t = 0;
		send(client,(char *)&t, sizeof(int),0);
		showMessage("Such file doesn't exist",1);
		return;
	}
	fclose(file);

	remove(name.c_str());
	send(client,(char *)&t, sizeof(int),0);
	showMessage("Delete file successfully "+ Converter::numberToString(t),1);
}

bool CServer20Dlg::mkdir( SOCKET client, string name) {
	int t = PathFileExistsA(name.c_str());
	if (t)
	{
		showMessage("Folder is already existed",1);
		send(client,(char *)&t, sizeof(int),0);
		return 0;
	}
	int check = _mkdir(name.c_str());
	if (check == 0)
	{
		showMessage("Create folder successfully",1);
	}
	else if (check == -1)
		showMessage("Failed to create folder",1);

	send(client,(char*)&check, sizeof(int),0);
	//showMessage(Converter::numberToString(check));
	return 1;
}

bool CServer20Dlg::rmdir(SOCKET client, string name) {
	int t = PathFileExistsA(name.c_str());
	int z;
	int y = 1;
	if (!t)
	{
		z = 0;
		showMessage("Folder doesn't exist",1);
	    send(client,(char *)&z, sizeof(int),0);
		return 0;
	}
	t = PathIsDirectoryEmptyA(name.c_str());
	if (!t)
	{
		z = 1;
		showMessage("Can't remove folder due to some problem",1);
		send(client,(char *)&z, sizeof(int),0);
		return 0;
	}
	int check = _rmdir(name.c_str());
	if (check == 0)
	{
		z = 2;
		showMessage("Remove folder successfully",1);
	}
	else if (check == -1)
	{
		z = 3;
		showMessage("Failed to remove folder",1);
	}

	send(client,(char *)&z, sizeof(int),0);
	return 1;
}


void CServer20Dlg::handleMsg(SOCKET client, string message) {
	vector<string> v = Tokenizer::Parse(message, DELIMITER);
	int option = Converter::StringToNumber(v[0]);
	switch (option) {

	case(LOG_IN): {
		showMessage("Log in");
		if (!logIn(User(v[1], v[2]))) sendMsg(client, "101"),showMessage("failed",1);
		else sendMsg(client, "102"),showMessage("successfully", 1);
		break;
	    }
	case(SIGN_UP): {
		showMessage("Sign up");
		if (signUp(User(v[1], v[2]))) {
			sendMsg(client, "103"); 
			showMessage("sucessfully", 1);
		}
		else sendMsg(client, "104"), showMessage("failed", 1);
		break;
	    }
	case(LS): {
		showMessage("Access to server folder",1);
		vector <string> files = ls();
		string list = "105";
		for (int i = 0; i < files.size(); i++) {
			list += '$';
			list += files[i];
		}
		sendMsg(client, list);
		break;
	}
	case(PUT_FILE): {
		showMessage("Upload file to server",1);
		put(client, v[1]);
		break;
	}
	case(GET_FILE): {
		showMessage("Download file from server",1);
		get(client, v[1]);
		break;
	}
	case(DELETE_FILE): {
		showMessage("Delete file in server",1);
		deleteFile(client, v[1]);
		break;
	}
	case(MKDIR): {
		showMessage("Create folder in server",1);
		mkdir(client, v[1]);
		break;
	}
	case(RMDIR): {
		showMessage("Delete folder in server",1);
		rmdir(client, v[1]);
		break;
	}
	default: {
	     //	showMessage(message);
	}
	}
	
	
}


LRESULT CServer20Dlg::  SockMsg(WPARAM wParam, LPARAM lParam) {
	if (WSAGETSELECTERROR(lParam))
	{
		// Display the error and close the socket
		closesocket(wParam);
	}
	switch(WSAGETSELECTEVENT(lParam))
	{
	case FD_ACCEPT:
		{
		    idNumber++;
		    clients.push_back( Client(  accept(wParam,NULL,NULL),Converter::numberToString(idNumber) ) );
			showMessage("Found a new client ",1);
			break;
		}
	case FD_READ:
	   {
		   string ID = getClientId(wParam).id;
		   string mess;
		   if (!receiveMsg(wParam, mess)) {
			   break;
		   }
		   showMessage(ID);
		   handleMsg(wParam,mess);
		   break;
	   }
	case FD_CLOSE:
	   {
		   ii temp = getClientId(wParam);
		   int pos = temp.index;
		   string ID = temp.id;
		   showMessage(ID + " is out of service", 1);
		   closesocket(wParam);
		   clients.erase(clients.begin()+pos);
		   break;
	   }

	}
	return 0;
}

void CServer20Dlg::OnEnChangeMessage()
{
	// TODO:  If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialogEx::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.

	// TODO:  Add your control notification handler code here
}


void CServer20Dlg::OnBnClickedListen()
{
	// TODO: Add your control notification handler code here
	Listen();
}


void CServer20Dlg::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
}
